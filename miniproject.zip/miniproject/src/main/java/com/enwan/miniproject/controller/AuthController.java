package com.enwan.miniproject.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.enwan.miniproject.dto.NamesOnlyDto;
import com.enwan.miniproject.service.UserService;


@RestController
@RequestMapping("/")
public class AuthController {

	@Autowired
	private UserService userService;
	
	@GetMapping({"", "login"})
	public ModelAndView index() {
		ModelAndView view = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			for (GrantedAuthority authority: auth.getAuthorities()) {
				if (authority.getAuthority().equals("ROLE_ADMIN")) {
					return new ModelAndView(new RedirectView("/admin"));
				} else if (authority.getAuthority().equals("ROLE_FACILITATOR")) {
					return new ModelAndView(new RedirectView("/facilitator"));
				} else {
					return new ModelAndView(new RedirectView("/trainee"));
				}
			}
		}
		view.addObject("title", "Bootcamp Tracking System");
		view.setViewName("main/login");
		return view;
	}
	
	@GetMapping("user")
	public NamesOnlyDto sample() {
		return userService.getNames("j.sajot");
	}
}
