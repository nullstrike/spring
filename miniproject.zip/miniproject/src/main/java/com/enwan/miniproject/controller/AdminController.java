package com.enwan.miniproject.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("/xadmin")
public class AdminController {

	@GetMapping
	public ModelAndView index() {
		ModelAndView view = new ModelAndView();
		view.addObject("content", "admin/index");
		view.addObject("title", "Bootcamp Tracking System");
		view.addObject("require_table", true);
		view.setViewName("layouts/template");
		return view;
	}
	
}
