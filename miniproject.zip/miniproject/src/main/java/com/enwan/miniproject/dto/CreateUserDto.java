package com.enwan.miniproject.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreateUserDto {
	

	@Size(min = 2, max = 40, message = "Firstname must be between 2 to 40 characters")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only letters are allowed")
	private String firstName;
	
	private String middleName;

	@Size(min = 2, max = 40, message = "Lastname must be between 2 to 40 characters")
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only letters are allowed")
	private String lastName;
	
	@Size(max = 20, message = "Username must not more than 20 characters")
	private String username;
	
	@NotNull
	private Integer role;

}
