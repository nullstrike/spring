package com.enwan.miniproject.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enwan.miniproject.dto.CreateUserDto;
import com.enwan.miniproject.dto.UserDetailDto;
import com.enwan.miniproject.response.RequestResponse;
import com.enwan.miniproject.service.UserService;


@RestController
@RequestMapping("/api")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/users")
	public ResponseEntity<?> createUser(@Valid @RequestBody CreateUserDto createUserDto){
		if (userService.checkUsernameExist(createUserDto.getUsername())) {
			return new ResponseEntity<>(new RequestResponse(false, "Username already taken"), HttpStatus.BAD_REQUEST);
		}
		
		userService.createUser(createUserDto);
		return new ResponseEntity<>(new RequestResponse(true, "Successfully created user."), HttpStatus.OK);
	}
	
	@GetMapping("/users")
	public List<UserDetailDto> getUsers(){
		return userService.getUsers();
	}
	
}
