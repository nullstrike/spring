package com.enwan.miniproject.constraint;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.enwan.miniproject.dto.ChangePasswordDto;

public class PasswordMatchesValidator implements ConstraintValidator<PasswordMatches, Object>  {

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		ChangePasswordDto user = (ChangePasswordDto) value;
		return user.getNewPassword().equals(user.getConfirmPassword());
	}
	@Override
	public void initialize(PasswordMatches constraintAnnotation) {
		ConstraintValidator.super.initialize(constraintAnnotation);
	}
	
}
