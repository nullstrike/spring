package com.enwan.miniproject.service;

import java.util.List;

import com.enwan.miniproject.dto.ChangePasswordDto;
import com.enwan.miniproject.dto.CreateUserDto;
import com.enwan.miniproject.dto.NamesOnlyDto;
import com.enwan.miniproject.dto.UserDetailDto;
import com.enwan.miniproject.model.User;

public interface UserService {
	User createUser(CreateUserDto createUserDto);
	User changePassword(ChangePasswordDto changePasswordDto);
	Boolean checkUsernameExist(String username);
	List<UserDetailDto> getUsers();
	NamesOnlyDto getNames(String username);
}
