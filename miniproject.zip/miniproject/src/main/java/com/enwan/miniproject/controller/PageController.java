package com.enwan.miniproject.controller;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.enwan.miniproject.dto.NamesOnlyDto;
import com.enwan.miniproject.service.UserService;

@RestController
public class PageController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/trainee")
	public ModelAndView traineeIndex(Principal principal) {
		return pageLoader(principal,"Trainee Home | Bootcamp Tracking System ","trainee/index", true, false);
	}
	
	@GetMapping("/admin")
	public ModelAndView adminIndex(Principal principal) {
		return pageLoader(principal,"Admin Home | Bootcamp Tracking System","admin/index", false, true);
	}
	
	private ModelAndView pageLoader(Principal principal, String title, String content, Boolean extra, Boolean table) {
		ModelAndView page = new ModelAndView();
		page.addObject("title", title);
		page.addObject("content", content);
		page.addObject("extra", extra);
		page.addObject("require_table", table);
		page.addObject("user", userInfo(principal));
		page.setViewName("layouts/template");
		return page;
	}
	
	private Map<String, String> userInfo(Principal principal) {
		NamesOnlyDto namesOnlyDto = userService.getNames(principal.getName());
		Map<String, String> userDetails = new HashMap<>();
		userDetails.put("fullname",namesOnlyDto.toString());
		userDetails.put("username", principal.getName());
		userDetails.put("role", namesOnlyDto.getRole());
		
		return userDetails;
	}
}
