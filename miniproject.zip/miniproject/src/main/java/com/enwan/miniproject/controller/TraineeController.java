package com.enwan.miniproject.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.enwan.miniproject.dto.NamesOnlyDto;
import com.enwan.miniproject.service.UserService;


@RestController
@RequestMapping("/xtrainee")
public class TraineeController {

	@Autowired
	private UserService userService;
	
	
	@GetMapping
	public ModelAndView index(Principal principal) {

		ModelAndView view = new ModelAndView();
		
		view.addObject("title", "Trainee Program Plan | Bootcamp Tracking System");
		view.addObject("content", "trainee/index");
		view.addObject("extra", false);
		view.addObject("user", userInfo(principal));
		view.setViewName("layouts/template");
		
		return view;
	}
	
	public Map<String, String> userInfo(Principal principal) {
		NamesOnlyDto namesOnlyDto = userService.getNames(principal.getName());
		Map<String, String> userDetails = new HashMap<>();
		userDetails.put("fullname",namesOnlyDto.toString());
		userDetails.put("role", namesOnlyDto.getRole());
		
		return userDetails;
	}
	
}
