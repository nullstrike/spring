$(function () {

	function transformToJSON(form){
		var data = {};
		
		form.serializeArray().map(function(input){
			data[input.name] = input.value;
		});
		
		return data;
	}
	
	$("#logOut").on("click", function() {
		$("#logoutForm").submit();
	});
});