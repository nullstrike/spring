   $(function() {
        	   var empty_template = '<tr class="task_placeholder header">' +
				'<td>Nothing to show here...</td>'	+
					'</tr>';
                $('#calendar').fullCalendar();
                $('#add_task').on('click', function() {
    				var task = $("textarea[name=task]");
    				var type  = parseInt($("select").val());
    				var template = '<tr>' +
                    					'<td class="" style="width:75%">' + task.val() + '</td>' +
                    					'<td class="" style="width:25%">' + '<a href="javascript:void(0)" class="btn btn-sm task_edit"><i class="dropdown-icon fe fe-edit-2"></i> Edit </a>' +
                    					'<a href="javascript:void(0)" class="btn btn-sm task_save" style="display:none;"><i class="dropdown-icon fe fe-save"></i> Save </a>' +
                						
                    					'<a href="javascript:void(0)" class="btn btn-sm  task_delete text-danger"><i class="dropdown-icon fe fe-trash" ></i> Delete </a>' + '</td>' + 
                				
                   					'</tr>';
                   					
                   	
                   					
                   	if (!$.trim($("#task").val())) {
						alert("task should not be empty");
					} else {
						if (type === 0){
	    					$("#complete_list").append(template).find("tr.task_placeholder").remove();
	    				}
	    				
	    				if (type === 1) {
	    					$("#challenge_list").append(template).find("tr.task_placeholder").remove();
	    				}
	    				
	    				if (type === 2) {
	    					$("#todo_list").append(template).find("tr.task_placeholder").remove();
	    				}
	    				task.val("");
					} 	
    			});
                
                $("table tbody").on("click", ".task_edit", function() {
                	var val = $(this).closest("tr").find("td:first").text();
                	$(this).closest("tr").find("td:first").html("<textarea class='form-control' autocomplete='off'>" + val + "</textarea>");
                	$(this).hide();
                	$(this).closest("tr").find(".task_save").show();
                });
                
                $("table tbody").on("click", ".task_save", function () {
                	var parent = $(this).closest("tr");
                	var val = parent.find("textarea").val();
                	parent.find("td:first").html(val);
                	$(this).hide();
                	parent.find(".task_edit").show();
                });
                
                $("table tbody").on("click", ".task_delete", function() {
                	var temp = $(this).closest("tr").parent();
                	var row_count = $(this).closest("tr").parent();
                	$(this).closest("tr").remove();

                	console.log("current row number:" + row_count[0].children.length);
                	if (row_count[0].children.length === 0){
                		temp.append(empty_template);
                	}
                });
           });